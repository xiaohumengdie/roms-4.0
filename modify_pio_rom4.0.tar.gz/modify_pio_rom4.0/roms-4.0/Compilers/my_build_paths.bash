export MPI_ROOT=/home/SystemSoftware/intel2017/compilers_and_libraries_2017.1.132/linux/mpi/intel64
#export ESMF_DIR=${MPI_SOFT}/esmf_nc4
export NETCDF=/home/cesm01/software/coawst/netcdf
export NF_CONFIG=${NETCDF}/bin/nf-config
export NETCDF_INCDIR=${NETCDF}/include
export NETCDF4=1
export HDF5=/home/cesm01/software/coawst/hdf5
export HDF5_LIBDIR=${HDF5}/lib
export HDF5_INCDIR=${HDF5}/include

